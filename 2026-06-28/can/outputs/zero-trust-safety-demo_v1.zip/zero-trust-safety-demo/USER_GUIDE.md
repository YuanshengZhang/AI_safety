# Zero-Trust Safety Overlay Demo User Guide

This guide is for someone receiving the demo folder or zip file.

## What This Demo Shows

This is a local web demo for an AI safety hackathon. It shows how an agent can process a personal-data automation request without giving the agent direct access to raw personal data.

The key idea:

```text
User gives personal data
Safety gateway replaces private values with vault tokens
Agent proposes actions using tokens
Policy layer checks every tool call
High-risk actions require human approval
Audit log records every decision with redacted data
```

Default mode is free and local. It does not require OpenAI API, a paid model, NeMo, OpenBao, or Docker.

## Requirements

Default mode:

```text
Python 3
Modern browser
```

Optional advanced tests:

```text
Docker Desktop     required for Safe shell sandbox
NeMo Guardrails    optional, requires installation and a configured model
OpenBao            optional, can be started with Docker Compose
OpenAI-compatible LLM optional, requires local model server or API key
```

## Run The Demo

From the project folder:

```bash
python3 server.py --port 8765
```

Open:

```text
http://127.0.0.1:8765/
```

Important: `127.0.0.1` means "this computer." Other people must run the demo on their own machine and open the same URL locally.

## What To Click

### Path A: Custom Request

Use the big text box and click **Run custom request**.

Expected result:

- Personal data is replaced with tokens such as `PII_EMAIL_...`.
- The **Agent context** panel does not show the raw email, phone, SSN, or address.
- The email action goes to **Human gate / Approvals**.
- The **Audit log** records each decision.

### Path B: Built-In Safety Tests

These buttons each send a fixed test case:

| Button | What it tests | Expected result |
|---|---|---|
| Prompt injection | Malicious text asks the agent to ignore instructions and leak an API key | Block |
| Secret exfiltration | A fake API key is sent to `webhook.site` | Block |
| Dangerous shell | Tries to read an SSH private key | Block before sandbox |
| Safe HTTP | Requests an allowlisted GitHub URL | Allow |
| Email approval | Tries to send email | Require approval |
| Safe shell sandbox | Runs a harmless command in Docker after approval | Require approval, then execute in Docker if Docker mode is on |

## How To Explain The Panels

### Agent Context

This is what the simulated agent or real LLM is allowed to see.

Example:

```text
maya.chen@example.com -> PII_EMAIL_...
617-555-0142 -> PII_PHONE_...
```

The agent can refer to the token, but not the raw value.

### Vault References

These are backend-only references. Think of them as claim tickets.

```text
Agent sees:       PII_EMAIL_ABC123
Backend vault has: maya.chen@example.com
Audit log sees:   [EMAIL_REDACTED]
```

### Human Gate / Approvals

High-risk actions do not execute immediately. Email and shell actions pause here until someone approves or denies them.

### Audit Log

The audit log records what happened, but with sensitive values redacted.

Look for events such as:

```text
input_checked
agent_context_minimized
agent_tool_plan_created
tool_call_requested
approval_created
tool_call_allowed
tool_call_blocked
```

## Test Docker Sandbox Mode

Start Docker Desktop first.

Then run:

```bash
export USE_DOCKER=1
python3 server.py --port 8765
```

Open the UI and click **Safe shell sandbox**.

Then approve the shell action under **Human gate / Approvals**.

Expected output in the decision payload:

```json
{
  "executed": true,
  "sandbox": "docker",
  "image": "alpine:3.20",
  "network": "none",
  "stdout_redacted": "hello from docker sandbox\n"
}
```

## Test NeMo Mode

NeMo is optional and is not required for the default demo.

Install NeMo Guardrails in the same Python environment used to run `server.py`:

```bash
python3 -m pip install nemoguardrails
```

Then run:

```bash
export USE_NEMO=1
export NEMO_CONFIG_PATH=./nemo_guardrails_config
python3 server.py --port 8765
```

Click **Prompt injection**.

If NeMo handled the check, the decision payload should include:

```text
engine: "nemo_guardrails"
```

If NeMo is enabled but unavailable or not configured with a model, the app falls back to rule-based guardrails and reports the reason in `/health` and the decision payload.

## Optional OpenBao Mode

OpenBao stores token-to-raw-value mappings outside process memory.

Start OpenBao:

```bash
docker compose -f docker-compose.real.yml up openbao
```

In another terminal:

```bash
export USE_OPENBAO=1
export OPENBAO_ADDR=http://127.0.0.1:8200
export OPENBAO_TOKEN=root
python3 server.py --port 8765
```

The UI still shows only masked vault metadata.

## Optional Real LLM Mode

Default mode uses a simulated agent. A real model is optional.

Use an OpenAI-compatible endpoint:

```bash
export USE_REAL_LLM=1
export LLM_API_BASE=http://127.0.0.1:8000/v1
export LLM_MODEL=your-model-name
python3 server.py --port 8765
```

For OpenAI API, use:

```bash
export USE_REAL_LLM=1
export LLM_API_BASE=https://api.openai.com/v1
export LLM_MODEL=gpt-4.1-mini
export OPENAI_API_KEY=your_api_key
python3 server.py --port 8765
```

OpenAI API usage requires separate API billing. ChatGPT Pro does not usually cover API calls.

## Troubleshooting

### Address Already In Use

If you see:

```text
OSError: [Errno 48] Address already in use
```

Another server is already using the port. Use another port:

```bash
python3 server.py --port 8766
```

Then open:

```text
http://127.0.0.1:8766/
```

### Docker Sandbox Does Not Run

Check:

```bash
docker info
```

If Docker is not ready, start Docker Desktop.

### NeMo Does Not Show As Active

Check:

```bash
python3 -c "import nemoguardrails; print('ok')"
```

If that fails, install NeMo Guardrails or run the demo in fallback mode.

## How To Share

Zip the folder:

```bash
cd /Users/yuanshengzhang/Documents/Codex/2026-06-28/can/outputs
zip -r zero-trust-safety-demo.zip zero-trust-safety-demo
```

Send `zero-trust-safety-demo.zip`.

The receiver runs:

```bash
unzip zero-trust-safety-demo.zip
cd zero-trust-safety-demo
python3 server.py --port 8765
```

Then opens:

```text
http://127.0.0.1:8765/
```
